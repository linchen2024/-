# K230 TCP调试助手

## 项目简介
网络调试助手Web页面应用，实现TCP服务端与JPEG数据显示功能。支持实时接收TCP客户端发送的JPEG字节流数据，并在Web页面中以视频流形式显示。

## 功能特性
- TCP服务端监听指定IP和端口
- 接收JPEG字节流数据
- 实时视频流显示
- 支持多客户端连接
- 简洁的Web界面

## 技术架构
- 后端：Node.js + Express + WebSocket
- 前端：HTML5 + Canvas + WebSocket
- 通信：TCP + WebSocket

## 安装运行
```bash
npm install
npm start
```

## 使用方法
1. 打开浏览器访问 http://localhost:8080
2. 输入监听的IP地址和端口
3. 点击"启动监听"按钮
4. TCP客户端发送JPEG数据到指定地址
5. Web页面实时显示接收到的图像

## 文件结构
- `server.js` - 后端服务器，TCP服务端和WebSocket
- `config.js` - 统一配置文件
- `public/index.html` - 前端页面
- `public/script.js` - 前端JavaScript逻辑
- `package.json` - 项目依赖配置

## 配置说明
- `ip`: TCP监听IP地址
- `port`: TCP监听端口
- `wsPort`: WebSocket端口
- `frameRate`: 帧率设置
- `quality`: 图像质量

## 注意事项
- 确保防火墙允许指定端口
- JPEG数据需要包含完整的帧标记
- 支持多客户端同时连接 