let ws = null, canvas = document.getElementById('videoCanvas'), ctx = canvas.getContext('2d'), img = new Image(); //初始化变量
// 固定参数
const FIXED_IP = '192.168.43.88';
const FIXED_PORT = 80;

// 自动连接服务器
function autoStartServer() {
    document.getElementById('navbarStatus').textContent = '正在启动...';
    fetch(`/api/start?ip=${FIXED_IP}&port=${FIXED_PORT}`).then(() => {
        document.getElementById('navbarStatus').textContent = `监听 ${FIXED_IP}:${FIXED_PORT}`;
        document.getElementById('videoStatus').textContent = '等待连接...';
        connectWebSocket();
    }).catch(err => {
        document.getElementById('navbarStatus').textContent = '启动失败: ' + err.message;
    });
}
function stopServer() { //停止服务器
    fetch('/api/stop').then(() => { //调用后端API
        document.getElementById('status').textContent = '已停止'; //更新状态
        document.getElementById('videoContainer').style.display = 'none'; //隐藏视频界面
        if (ws) { ws.close(); ws = null; } //关闭WebSocket
        document.getElementById('videoStatus').textContent = '等待连接...';
    }).catch(err => { //错误处理
        document.getElementById('status').textContent = '停止失败: ' + err.message;
    });
} //错误处理
function connectWebSocket() { //连接WebSocket
    ws = new WebSocket('ws://localhost:3001'); //创建WebSocket连接
    ws.onopen = () => document.getElementById('videoStatus').textContent = '已连接，等待数据...'; //连接成功
    ws.onmessage = event => { //接收消息
        const blob = new Blob([event.data], { type: 'image/jpeg' }); //创建Blob
        const url = URL.createObjectURL(blob); //创建URL
        img.onload = () => { //图片加载完成
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height); //绘制到Canvas
            URL.revokeObjectURL(url);
        }; //释放URL
        img.src = url; //设置图片源
        document.getElementById('videoStatus').textContent = '正在接收数据...';
    }; //更新状态
    ws.onclose = () => document.getElementById('videoStatus').textContent = '连接已断开'; //连接关闭
    ws.onerror = err => document.getElementById('videoStatus').textContent = '连接错误: ' + err.message;
} //连接错误
// 涟漪动效
function addRipple(e) {
    const btn = e.currentTarget;
    const circle = document.createElement('span');
    circle.className = 'ripple';
    const rect = btn.getBoundingClientRect();
    circle.style.left = (e.clientX - rect.left) + 'px';
    circle.style.top = (e.clientY - rect.top) + 'px';
    btn.appendChild(circle);
    setTimeout(() => circle.remove(), 600);
}
// 绑定涟漪动效到所有按钮
window.addEventListener('DOMContentLoaded', () => {
    autoStartServer();
    document.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', addRipple);
    });
    // 命令历史弹窗
    const showBtn = document.getElementById('showHistoryBtn');
    const modal = document.getElementById('historyModal');
    const closeBtn = document.getElementById('closeHistory');
    if (showBtn && modal && closeBtn) {
        showBtn.onclick = () => { modal.style.display = 'block'; };
        closeBtn.onclick = () => { modal.style.display = 'none'; };
        window.onclick = function (event) {
            if (event.target === modal) modal.style.display = 'none';
        };
    }
});
// 控制命令映射
const controlCmds = {
    'btn-forward': 'e11f',
    'btn-backward': 'e12f',
    'btn-left': 'e51f',
    'btn-right': 'e52f',
    'btn-acc': 'e61f',
    'btn-dec': 'e62f',
    'btn-stop': 'e00f',
    'btn-up': 'e21f',
    'btn-down': 'e22f',
    'btn-climb': 'e31f',
    'btn-normal': 'e32f',
    'btn-light': null // 灯光开/关，需切换
};
let lightOn = false;
function sendControl(cmd, label) {
    fetch(`/api/control?cmd=${cmd}`);
    // 命令历史追加
    const ul = document.getElementById('cmdHistory');
    if (ul) {
        const li = document.createElement('li');
        li.textContent = `${new Date().toLocaleTimeString()} 发送命令: ${label || cmd}`;
        ul.appendChild(li);
        ul.scrollTop = ul.scrollHeight;
    }
}
window.onload = function () {
    Object.keys(controlCmds).forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        if (id === 'btn-light') {
            btn.onclick = function () {
                lightOn = !lightOn;
                sendControl(lightOn ? 'e41f' : 'e42f', lightOn ? '灯光开' : '灯光关');
                btn.textContent = lightOn ? '灯光关' : '灯光开';
            };
        } else {
            btn.onclick = function () {
                sendControl(controlCmds[id], btn.textContent);
            };
        }
    });
    // 状态栏同步
    const status = document.getElementById('status');
    const navbarStatus = document.getElementById('navbarStatus');
    if (status && navbarStatus) {
        const observer = new MutationObserver(() => {
            navbarStatus.textContent = status.textContent;
        });
        observer.observe(status, { childList: true });
    }
    // 设备状态区假数据（可后续用WebSocket/接口替换）
    const deviceStatus = document.getElementById('deviceStatus');
    if (deviceStatus) {
        setInterval(() => {
            // 假数据：2台设备
            deviceStatus.textContent = '当前连接设备数 2：\n设备1 IP: 192.168.1.101\n设备2 IP: 192.168.1.102';
        }, 5000);
    }
};
// 涟漪动效样式
const rippleStyle = document.createElement('style');
rippleStyle.innerHTML = `.ripple {position: absolute;border-radius: 50%;background: rgba(0,122,255,0.18);transform: scale(0);animation: ripple 0.6s linear;pointer-events:none;width:120px;height:120px;z-index:2;}
@keyframes ripple {to {transform: scale(2.5);opacity: 0;}} button {position: relative;overflow: hidden;}`;
document.head.appendChild(rippleStyle); 