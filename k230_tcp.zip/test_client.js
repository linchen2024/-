const net = require('net'), fs = require('fs'), config = require('./config.js'); //导入依赖
const client = new net.Socket(); //创建TCP客户端
client.connect(80, '192.168.43.88', () => { //连接服务器
    console.log('TCP连接成功'); //连接成功
    client.write('test data'); //发送测试数据
}); //发送数据
client.on('data', data => console.log('收到数据:', data)); //处理接收到的数据
client.on('error', err => console.log('连接错误:', err)); //错误处理 