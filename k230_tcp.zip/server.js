const net = require('net'), ws = require('ws'), express = require('express'), config = require('./config.js'), app = express(), wss = new ws.Server({ port: config.wsPort }), clients = new Set(); let tcpServer = null; //导入依赖
// 全局维护已连接设备集合和顺序
const connectedSockets = new Set();
const deviceOrder = [];
app.use(express.static('public')); app.get('/', (req, res) => res.sendFile(__dirname + '/public/index.html')); //静态文件服务
app.get('/api/start', (req, res) => { //启动TCP服务端API
    const ip = req.query.ip || config.ip, port = parseInt(req.query.port) || config.port; //获取参数
    if (tcpServer) { tcpServer.close(); } //关闭现有服务
    function printConnectedIPs() {
        console.log(`当前连接设备数 ${connectedSockets.size}：`);
        deviceOrder.forEach((sock, idx) => {
            let addr = sock.remoteAddress;
            if (addr.startsWith('::ffff:')) addr = addr.replace('::ffff:', '');
            console.log(`设备${idx + 1} IP: ${addr}`);
        });
        if (connectedSockets.size === 0) console.log('无设备连接');
    }
    function getDeviceIndex(socket) {
        return deviceOrder.indexOf(socket);
    }
    tcpServer = net.createServer(socket => { //创建TCP服务端
        connectedSockets.add(socket);
        deviceOrder.push(socket);
        printConnectedIPs();
        let buffer = Buffer.alloc(0); socket.on('data', data => { //接收数据
            buffer = Buffer.concat([buffer, data]); let start = 0; while ((start = buffer.indexOf(0xFF, start)) !== -1 && start + 1 < buffer.length) { //查找JPEG开始标记
                if (buffer[start + 1] === 0xD8) { //JPEG开始
                    let end = buffer.indexOf(0xFF, start + 2); while (end !== -1 && end + 1 < buffer.length) { //查找JPEG结束标记
                        if (buffer[end + 1] === 0xD9) { //JPEG结束
                            const jpegData = buffer.slice(start, end + 2); clients.forEach(client => client.readyState === ws.OPEN && client.send(jpegData)); //发送到WebSocket客户端
                            buffer = buffer.slice(end + 2); break; //移除已处理数据
                        } end = buffer.indexOf(0xFF, end + 1);
                    } break; //继续查找
                } start++;
            }
        });
        // 新增：断开连接时移除并打印
        function handleDisconnect() {
            const idx = getDeviceIndex(socket);
            if (idx !== -1) {
                let addr = socket.remoteAddress;
                if (addr.startsWith('::ffff:')) addr = addr.replace('::ffff:', '');
                console.log(`设备${idx + 1}断开连接`);
                deviceOrder.splice(idx, 1);
            }
            connectedSockets.delete(socket);
            printConnectedIPs();
        }
        socket.on('close', handleDisconnect);
        socket.on('error', err => { console.log('TCP错误:', err); handleDisconnect(); });
    }); //错误处理
    tcpServer.listen(port, ip, () => { console.log(`TCP服务端监听 ${ip}:${port}`); res.json({ success: true }); }); //启动TCP服务
});
app.get('/api/stop', (req, res) => { if (tcpServer) { tcpServer.close(); tcpServer = null; console.log('TCP服务端已停止'); } res.json({ success: true }); }); //停止API
app.get('/api/control', (req, res) => {
    const cmd = req.query.cmd;
    if (!cmd) return res.json({ success: false, msg: '缺少cmd参数' });
    // 发送到所有已连接设备
    if (tcpServer && typeof connectedSockets !== 'undefined') {
        for (const sock of connectedSockets) {
            try {
                sock.write(cmd);
            } catch (e) {
                console.log('发送命令失败:', e);
            }
        }
    }
    res.json({ success: true });
});
wss.on('connection', client => { clients.add(client); client.on('close', () => clients.delete(client)); }); //WebSocket连接管理
app.listen(8080, () => console.log('Web服务器运行在 http://localhost:8080')); //启动Web服务器 