/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-08     31879       the first version
 */
#ifndef BSP_BSP_SYSTEM_H_

#define BSP_BSP_SYSTEM_H_

//C
#include <stdio.h>
#include <string.h>

//RTT
#include <rtthread.h>
#include <rtdevice.h>
#include "drv_common.h"

#include <rtthread.h>
#include <sys/socket.h> /* 使用BSD socket，需要包含socket.h头文件 */
#include <netdb.h>
#include <string.h>
#include <finsh.h>


//BSP
#include <TCP/bsp_tcp.h>
#include "bsp_douji.h"
#include "bsp_uart.h"
#include "bsp_motor.h"
#include "bsp_tcp.h"

extern uint8_t MOTOR_FLAG;


#endif /* BSP_BSP_SYSTEM_H_ */
