/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-09     31879       the first version
 */

#include "bsp_douji.h"
#include <SCServo.h>

#define FEN_BIAN_LV     2


#define DOUJI_1_START   3950
#define DOUJI_1_END   5000

#define DOUJI_2_START   918
#define DOUJI_2_END   -150

#define DOUJI_3_START   100
#define DOUJI_3_END   600

#define DOUJI_4_START   100
#define DOUJI_4_END   750

#define DOUJI_5_START   364
#define DOUJI_5_END   900

#define DOUJI_6_START   239
#define DOUJI_6_END   -300


void setup(void)
{
    setEnd(1);
}


void ftBus_Delay(void)
{
    rt_thread_mdelay(1);
}


//void duoji1_contrl(uint8_t sel)
//{
//    int16_t angle_data = (DOUJI_1_END - DOUJI_1_START) / FEN_BIAN_LV;
//
//    WritePosEx(1, (DOUJI_1_START + sel*angle_data), 1000, 0);
//}
//void duoji2_contrl(uint8_t sel)
//{
//    int16_t angle_data = (DOUJI_1_END - DOUJI_1_START) / FEN_BIAN_LV;
//
//    WritePosEx(1, (DOUJI_1_START - sel*angle_data), 1000, 0);
//}
void duoji3_contrl(uint8_t sel)
{
    int16_t angle_data = (DOUJI_3_END - DOUJI_3_START) / FEN_BIAN_LV;

    WritePosEx(3, (DOUJI_3_START + sel*angle_data), 1000, 0);
}
void duoji4_contrl(uint8_t sel)
{
    int16_t angle_data = (DOUJI_4_END - DOUJI_4_START) / FEN_BIAN_LV;

    WritePosEx(4, (DOUJI_4_START + sel*angle_data), 1000, 0);
}
void duoji5_contrl(uint8_t sel)
{
    int16_t angle_data = (DOUJI_5_END - DOUJI_5_START) / FEN_BIAN_LV;

    WritePosEx(5, (DOUJI_5_START + sel*angle_data), 1000, 0);
}
void duoji6_contrl(uint8_t sel)
{
    int16_t angle_data = (DOUJI_6_START - DOUJI_6_END) / FEN_BIAN_LV;

    WritePosEx(6, (DOUJI_6_START - sel*angle_data), 1000, 0);
}

void douji_12_ctrl(uint8_t on)
{
    if (on == 0) {
        WritePosEx(1, 3950, 1000, 0);
        WritePosEx(2, 918, 1000, 0);
    } else {
        WritePosEx(1, 5000, 1000, 0);
        WritePosEx(2, -150, 1000, 0);
    }
    rt_thread_mdelay(500);
}

void douji_3456_ctrl(uint8_t sel)
{
    duoji3_contrl(sel);
    duoji4_contrl(sel);
    duoji5_contrl(sel);
    duoji6_contrl(sel);
    rt_thread_mdelay(500);
}


void douji_entry(void *parameter)
{
    rt_kprintf("douji start!!!\r\n");
    douji_3456_ctrl(0);
    rt_thread_mdelay((500)*1000/(1000) + 100);//[(P1-P0)/V]*1000 + 100
    while(0)
    {

    }
}


int duoji_init(void)
{
    rt_thread_t thread = RT_NULL;




    thread = rt_thread_create("douji", douji_entry, RT_NULL, 1024, 25, 30);

    if(thread != RT_NULL)
    {
        rt_thread_startup(thread);
    } else {
        return RT_ERROR;
    }


    return RT_EOK;

}

INIT_APP_EXPORT(duoji_init);

