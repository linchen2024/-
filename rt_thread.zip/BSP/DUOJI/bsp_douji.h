/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-09     31879       the first version
 */
#ifndef BSP_DUOJI_BSP_DOUJI_H_
#define BSP_BSP_DOUJI_H_

#include "bsp_system.h"

void ftBus_Delay(void);

void douji_12_ctrl(uint8_t on);
void douji_3456_ctrl(uint8_t sel);

#endif /* BSP_DUOJI_BSP_DOUJI_H_ */
