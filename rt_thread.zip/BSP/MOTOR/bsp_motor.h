/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-09     31879       the first version
 */
#ifndef BSP_MOTOR_BSP_MOTOR_H_
#define BSP_MOTOR_BSP_MOTOR_H_

#include <bsp_system.h>


#define AIN1_PIN GET_PIN(I, 2)
#define AIN2_PIN GET_PIN(I, 1)

#define BIN1_PIN GET_PIN(E, 4)
#define BIN2_PIN GET_PIN(E, 5)

#define CIN1_PIN GET_PIN(H, 7)
#define CIN2_PIN GET_PIN(H, 9)

#define DIN1_PIN GET_PIN(H, 2)
#define DIN2_PIN GET_PIN(B, 1)

#define AIN1_OUT(i) rt_pin_write(AIN1_PIN, (i == 1)?PIN_HIGH:PIN_LOW)
#define AIN2_OUT(i) rt_pin_write(AIN2_PIN, (i == 1)?PIN_HIGH:PIN_LOW)

#define BIN1_OUT(i) rt_pin_write(BIN1_PIN, (i == 1)?PIN_HIGH:PIN_LOW)
#define BIN2_OUT(i) rt_pin_write(BIN2_PIN, (i == 1)?PIN_HIGH:PIN_LOW)

#define CIN1_OUT(i) rt_pin_write(CIN1_PIN, (i == 1)?PIN_HIGH:PIN_LOW)
#define CIN2_OUT(i) rt_pin_write(CIN2_PIN, (i == 1)?PIN_HIGH:PIN_LOW)

#define DIN1_OUT(i) rt_pin_write(DIN1_PIN, (i == 1)?PIN_HIGH:PIN_LOW)
#define DIN2_OUT(i) rt_pin_write(DIN2_PIN, (i == 1)?PIN_HIGH:PIN_LOW)


void AO_Control(uint8_t dir, uint32_t speed);
void BO_Control(uint8_t dir, uint32_t speed);
void CO_Control(uint8_t dir, uint32_t speed);
void DO_Control(uint8_t dir, uint32_t speed);

void mode_0_11(void);//电机正传
void mode_0_12(void);//电机反传


void motor_OFF(void);


#endif /* BSP_MOTOR_BSP_MOTOR_H_ */
