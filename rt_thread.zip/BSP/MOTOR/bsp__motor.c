/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-09     31879       the first version
 */
#include "bsp_motor.h"

#define PWM_TIME 100000

#define PWM2_NAME        "pwm2"  /* PWM设备名称 */
#define PWM2_CHANNEL_1     1       /* PWM通道 */
#define PWM2_CHANNEL_2     2       /* PWM通道 */

#define PWM4_NAME        "pwm4"  /* PWM设备名称 */
#define PWM4_CHANNEL_3     3       /* PWM通道 */
#define PWM4_CHANNEL_4     4       /* PWM通道 */

struct rt_device_pwm *pwm_2_dev;      /* PWM设备句柄 */
struct rt_device_pwm *pwm_4_dev;      /* PWM设备句柄 */

#define HIGH_SPEED  0.35
#define LOW_SPEED   0.15

int Pwm2_Init(void)
{
    /* 查找设备 */
    pwm_2_dev = (struct rt_device_pwm *)rt_device_find(PWM2_NAME);
    if (pwm_2_dev == RT_NULL)
    {
        rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM2_NAME);
        return RT_ERROR;
    }

    rt_kprintf("%s\r\n",pwm_2_dev);//打印设备号
    /* 设置PWM周期和脉冲宽度默认值 */
    rt_pwm_set(pwm_2_dev, PWM2_CHANNEL_1, 100000, 10000);
    /* 使能设备 */
    rt_pwm_enable(pwm_2_dev, PWM2_CHANNEL_1);
    /* 设置PWM周期和脉冲宽度默认值 */
    rt_pwm_set(pwm_2_dev, PWM2_CHANNEL_2, 100000, 10000);
    /* 使能设备 */
    rt_pwm_enable(pwm_2_dev, PWM2_CHANNEL_2);



    return RT_EOK;
}

int Pwm4_Init(void)
{
    /* 查找设备 */
    pwm_4_dev = (struct rt_device_pwm *)rt_device_find(PWM4_NAME);
    if (pwm_4_dev == RT_NULL)
    {
        rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM4_NAME);
        return RT_ERROR;
    }

    rt_kprintf("%s\r\n",pwm_4_dev);//打印设备号
    /* 设置PWM周期和脉冲宽度默认值 */
    rt_pwm_set(pwm_4_dev, PWM4_CHANNEL_3, 100000, 20000);
    /* 使能设备 */
    rt_pwm_enable(pwm_4_dev, PWM4_CHANNEL_3);
    /* 设置PWM周期和脉冲宽度默认值 */
    rt_pwm_set(pwm_4_dev, PWM4_CHANNEL_4, 100000, 20000);
    /* 使能设备 */
    rt_pwm_enable(pwm_4_dev, PWM4_CHANNEL_4);


    return RT_EOK;
}


rt_uint8_t IN_PIN_Init(void)
{
    rt_pin_mode(AIN1_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(AIN2_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(BIN1_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(BIN2_PIN, PIN_MODE_OUTPUT);


    rt_pin_mode(CIN1_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(CIN2_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(DIN1_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(DIN2_PIN, PIN_MODE_OUTPUT);

    rt_pin_write(AIN1_PIN, PIN_LOW);
    rt_pin_write(AIN2_PIN, PIN_LOW);
    rt_pin_write(BIN1_PIN, PIN_LOW);
    rt_pin_write(BIN2_PIN, PIN_LOW);
    rt_pin_write(CIN1_PIN, PIN_LOW);
    rt_pin_write(CIN2_PIN, PIN_LOW);
    rt_pin_write(DIN1_PIN, PIN_LOW);
    rt_pin_write(DIN2_PIN, PIN_LOW);
    return RT_EOK;
}





/******************************************************************
 * 函 数 名 称：AO_Control
 * 函 数 说 明：A端口电机控制
 * 函 数 形 参：dir旋转方向 1正转0反转   speed旋转速度，范围（0 ~ per-1）
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：无
******************************************************************/

void motor_OFF(void)
{
    AO_Control(0,0);//A端电机正转
    BO_Control(0,0);
    CO_Control(0,0);//A端电机正转
    DO_Control(0,0);
}


void AO_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 0 )
    {
        AIN1_OUT(0);
        AIN2_OUT(1);
    }
    else
    {
        AIN1_OUT(1);
        AIN2_OUT(0);
    }
    rt_pwm_set(pwm_2_dev, PWM2_CHANNEL_2, PWM_TIME, speed);
}

/******************************************************************
 * 函 数 名 称：AO_Control
 * 函 数 说 明：A端口电机控制
 * 函 数 形 参：dir旋转方向 1正转0反转   speed旋转速度，范围（0 ~ per-1）
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：无
******************************************************************/
void BO_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 1 )
    {
        BIN1_OUT(0);
        BIN2_OUT(1);
    }
    else
    {
        BIN1_OUT(1);
        BIN2_OUT(0);
    }
    rt_pwm_set(pwm_4_dev, PWM4_CHANNEL_4, PWM_TIME, speed);
}

/******************************************************************
 * 函 数 名 称：AO_Control
 * 函 数 说 明：A端口电机控制
 * 函 数 形 参：dir旋转方向 1正转0反转   speed旋转速度，范围（0 ~ per-1）
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：无
******************************************************************/
void CO_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 0 )
    {
        CIN1_OUT(0);
        CIN2_OUT(1);
    }
    else
    {
        CIN1_OUT(1);
        CIN2_OUT(0);
    }
    rt_pwm_set(pwm_2_dev, PWM2_CHANNEL_1, PWM_TIME, speed);
}

/******************************************************************
 * 函 数 名 称：AO_Control
 * 函 数 说 明：A端口电机控制
 * 函 数 形 参：dir旋转方向 1正转0反转   speed旋转速度，范围（0 ~ per-1）
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：无
******************************************************************/
void DO_Control(uint8_t dir, uint32_t speed)
{
    if( dir == 0 )
    {
        DIN1_OUT(0);
        DIN2_OUT(1);
    }
    else
    {
        DIN1_OUT(1);
        DIN2_OUT(0);
    }
    rt_pwm_set(pwm_4_dev, PWM4_CHANNEL_3, PWM_TIME, speed);
}


/**********************************************************************************/

/*
 *   前
 * A    D
 * B    C
 * */
void mode_0_11(void)//电机正传
{
    AO_Control(0,PWM_TIME*HIGH_SPEED);//A端电机正转
    BO_Control(0,PWM_TIME*HIGH_SPEED);
    CO_Control(0,PWM_TIME*HIGH_SPEED);//A端电机正转
    DO_Control(0,PWM_TIME*HIGH_SPEED);
    //delay_ms(500);
}
void mode_0_12(void)//电机正传
{
    AO_Control(1,PWM_TIME*HIGH_SPEED);//A端电机正转
    BO_Control(1,PWM_TIME*HIGH_SPEED);
    CO_Control(1,PWM_TIME*HIGH_SPEED);//A端电机正转
    DO_Control(1,PWM_TIME*HIGH_SPEED);
    //delay_ms(500);
}

void mode_0_2(void)//电机左转
{
    AO_Control(1,PWM_TIME*LOW_SPEED);//A端电机正转
    BO_Control(1,PWM_TIME*LOW_SPEED);
    CO_Control(0,PWM_TIME*LOW_SPEED);//A端电机正转
    DO_Control(0,PWM_TIME*LOW_SPEED);
    //delay_ms(500);
}
/*
 *   前
 * A    D
 * B    C
 * */
void mode_0_3(void)//电机右转
{
    AO_Control(0,PWM_TIME*HIGH_SPEED);//A端电机正转
    BO_Control(0,PWM_TIME*HIGH_SPEED);
    CO_Control(1,PWM_TIME*HIGH_SPEED);//A端电机正转
    DO_Control(1,PWM_TIME*HIGH_SPEED);
    //delay_ms(500);
}
/*
 *   前
 * A    D
 * B    C
 * */
void mode_0_4(void)//电机停转
{
    AO_Control(0,0);
    BO_Control(0,0);
    CO_Control(0,0);
    DO_Control(0,0);
    //delay_ms(500);
}
/*
 *   前
 * A    D
 * B    C
 * */
void mode_1_1(void)//电机正传
{
    AO_Control(0,PWM_TIME*0.8);//A端电机正转
    BO_Control(0,PWM_TIME*0.8);
    CO_Control(0,PWM_TIME*0.8);//A端电机正转
    DO_Control(0,PWM_TIME*0.8);
    //delay_ms(500);
}
/*
 *   前
 * A    D
 * B    C
 * */
void mode_1_2(void)//电机左转
{
    AO_Control(0,PWM_TIME*0.5);
    BO_Control(0,PWM_TIME*0.5);
    CO_Control(0,PWM_TIME*0.8);
    DO_Control(0,PWM_TIME*0.8);
    //delay_ms(500);
}

void mode_1_3(void)//电机右转
{
    AO_Control(0,PWM_TIME*0.8);
    BO_Control(0,PWM_TIME*0.8);
    CO_Control(0,PWM_TIME*0.5);
    DO_Control(0,PWM_TIME*0.5);
    //delay_ms(500);
}


uint8_t MOTOR_FLAG = 255;

uint8_t TOF_DATA_reg = 0;
void MOTOR_SEL(uint8_t sel)
{
    switch(sel)
    {
        case 255: //撞墙左转
            mode_0_2();
            rt_thread_mdelay(1000);
            TOF_DATA_reg = 0;
            break;
        case 0:
            motor_OFF();
            break;
        case 1://前进
            mode_0_11();
            break;
        case 2://后退
            mode_0_12();
            break;
        case 3:

            break;
        case 4:

            break;
        case 5:

            break;
        case 6:

            break;

    }
}


void pwm_entry(void *parameter)
{
    motor_OFF();
    MOTOR_FLAG = 0;
    while(1)
    {
//        rt_kprintf("TOF : %d\r\n", TOF_DATA);
        if((TOF_DATA < 650) && (TOF_DATA > 0))
        {
            TOF_DATA_reg = 255;
            MOTOR_SEL(TOF_DATA_reg);
        }
        if(TOF_DATA_reg == 255)
        {
            TOF_DATA = 0;
        } else if(TOF_DATA_reg == 0)
        {
            MOTOR_SEL(MOTOR_FLAG);
        }




        rt_thread_mdelay(50);
    }
}


int pwm_init(void)
{
    rt_thread_t thread;


    IN_PIN_Init();

    Pwm2_Init();
    Pwm4_Init();

    thread = rt_thread_create("pwm_entry",
                                pwm_entry,
                                RT_NULL,
                                4096,
                                25,
                                300);

    if(thread != RT_NULL)
    {
        rt_thread_startup(thread);
    } else {
        return RT_ERROR;
    }


    return RT_EOK;
}


INIT_APP_EXPORT(pwm_init);

