/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-08     31879       the first version
 */
#ifndef BSP_TCP_BSP_TCP_H_
#define BSP_BSP_TCP_H_

#include <bsp_system.h>



int tcpclient_init(void);

#endif /* BSP_TCP_BSP_TCP_H_ */
