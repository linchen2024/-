/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-08     31879       the first version
 */

#include <TCP/bsp_tcp.h>


#define BUFSZ   1024

//#define HOST_IP     "192.168.43.88"
//#define HOST_PORT   80
#define HOST_IP     "192.168.0.189"
#define HOST_PORT   5000

static const char send_data[] = "RTT RECE OK!"; /* 发送用到的数据 */

static int ret;
static char *recv_data;
static struct hostent *host;
static int sock, bytes_received;
static struct sockaddr_in server_addr;


void tcpclient_entry(void *parameter)
{
    while (1)
    {
        /* 从sock连接中接收最大BUFSZ - 1字节数据 */
        bytes_received = recv(sock, recv_data, BUFSZ - 1, 0);
        if (bytes_received < 0)
        {
            /* 接收失败，关闭这个连接 */
            closesocket(sock);
            rt_kprintf("\nreceived error,close the socket.\r\n");
            /* 释放接收缓冲 */
            rt_free(recv_data);
            break;
        }
        else if (bytes_received == 0)
        {
            /* 默认 recv 为阻塞模式，此时收到0认为连接出错，关闭这个连接 */
            closesocket(sock);
            rt_kprintf("\nreceived error,close the socket.\r\n");
            /* 释放接收缓冲 */
            rt_free(recv_data);
            break;
        }
        /* 有接收到数据，把末端清零 */
        recv_data[bytes_received] = '\0';
        if (strncmp(recv_data, "q", 1) == 0 || strncmp(recv_data, "Q", 1) == 0)
        {
            /* 如果是首字母是q或Q，关闭这个连接 */
            closesocket(sock);
            rt_kprintf("\n got a 'q' or 'Q',close the socket.\r\n");
            /* 释放接收缓冲 */
            rt_free(recv_data);
            break;
        } else if(recv_data[0] == 'e' && recv_data[bytes_received-1] == 'f')
        {
            switch(recv_data[1])
            {
                case '0':
                    MOTOR_FLAG = 0;
                    rt_kprintf("TCP_rece:00, 电机停止\r\n");
                break;
                case '1':
                    if (recv_data[2] == '1') {
                        rt_kprintf("TCP_rece:11,前进\r\n");
                        MOTOR_FLAG = 1;
                    } else if(recv_data[2] == '2') {
                        rt_kprintf("TCP_rece:12，后退\r\n");
                        MOTOR_FLAG = 2;
                    }
                    break;
                case '2':
                    if (recv_data[2] == '1') {
                        rt_kprintf("TCP_rece:21，趴下\r\n");
                        douji_3456_ctrl(3);
                    } else if(recv_data[2] == '2') {
                        rt_kprintf("TCP_rece:22，升起\r\n");
                        douji_3456_ctrl(0);
                    }
                    break;
                case '3':
                    if (recv_data[2] == '2') {
                        rt_kprintf("TCP_rece:31，收缩\r\n");
                        douji_12_ctrl(0);
                    } else if(recv_data[2] == '1') {
                        rt_kprintf("TCP_rece:32，张开\r\n");
                        douji_12_ctrl(1);
                    }
                    break;
                case '4':
                    if (recv_data[2] == '1') {
                        rt_kprintf("TCP_rece:41\r\n");
                    } else if(recv_data[2] == '2') {
                        rt_kprintf("TCP_rece:42\r\n");
                    }
                    break;
                case '5':
                    if (recv_data[2] == '1') {
                        rt_kprintf("TCP_rece:51\r\n");
                    } else if(recv_data[2] == '2') {
                        rt_kprintf("TCP_rece:52\r\n");
                    }
                    break;
            }

        }
        else
        {
            /* 在控制终端显示收到的数据 */
            rt_kprintf("\nReceived data = %s ", recv_data);
        }
        /* 发送数据到sock连接 */
        ret = send(sock, send_data, strlen(send_data), 0);
        if (ret < 0)
        {
            /* 接收失败，关闭这个连接 */
            closesocket(sock);
            rt_kprintf("\nsend error,close the socket.\r\n");
            rt_free(recv_data);
            break;
        }
        else if (ret == 0)
        {
            /* 打印send函数返回值为0的警告信息 */
            rt_kprintf("\n Send warning,send function return 0.\r\n");
        }
    }
}


int tcpclient_init(void)
{
    rt_thread_t thread = RT_NULL;

    /* 通过函数入口参数url获得host地址（如果是域名，会做域名解析） */
    host = gethostbyname(HOST_IP);
    /* 分配用于存放接收数据的缓冲 */
    recv_data = rt_malloc(BUFSZ);
    if (recv_data == RT_NULL)
    {
        rt_kprintf("No memory\n");
        return RT_ERROR;
    }
    /* 创建一个socket，类型是SOCKET_STREAM，TCP类型 */
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        /* 创建socket失败 */
        rt_kprintf("Socket error\n");
        /* 释放接收缓冲 */
        rt_free(recv_data);
        return RT_ERROR;
    }
    /* 初始化预连接的服务端地址 */
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(HOST_PORT);
    server_addr.sin_addr = *((struct in_addr *)host->h_addr);
    rt_memset(&(server_addr.sin_zero), 0, sizeof(server_addr.sin_zero));
    /* 连接到服务端 */
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) == -1)
    {
        /* 连接失败 */
        rt_kprintf("Connect fail!\n");
        closesocket(sock);
        /*释放接收缓冲 */
        rt_free(recv_data);
        return RT_ERROR;
    }

    thread = rt_thread_create("thread",
                                tcpclient_entry,
                                RT_NULL,
                                4096,
                                25,
                                30);


    if(thread != RT_NULL)
    {
        rt_kprintf("TCP Client Start\n");
        rt_thread_startup(thread);
    } else {
        return RT_ERROR;
    }


    return RT_EOK;
}

