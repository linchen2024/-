/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-08     31879       the first version
 */

#include "bsp_uart.h"


#if UART2_ENABLE

#define UART2_DEVICE_NAME "uart2"       // 串口设备名称
#define DEBUG_MESSAGE "uart2 Application Initialized.\r\n"

struct rt_device *UART2_dev;

/* UART2应用初始化函数 */
int UART2_app_init(void)
{
 rt_err_t result;
 struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;


 /* 查找串口设备 */
 UART2_dev = rt_device_find(UART2_DEVICE_NAME);
 if (!UART2_dev)
 {
     rt_kprintf("Find %s failed!\n", UART2_DEVICE_NAME);
     return RT_ERROR;
 }

 /* 配置串口参数（可根据需要修改） */
 config.baud_rate = BAUD_RATE_115200; /* 波特率 */
 config.data_bits = DATA_BITS_8;      /* 数据位 */
 config.stop_bits = STOP_BITS_1;      /* 停止位 */
 config.parity    = PARITY_NONE;      /* 无奇偶校验 */

 /* 控制串口设备，设置配置参数 */
 result = rt_device_control(UART2_dev, RT_DEVICE_CTRL_CONFIG, &config);
 if (result != RT_EOK)
 {
     rt_kprintf("Configure %s failed!\n", UART2_DEVICE_NAME);
     return RT_ERROR;
 }


 /* 打开串口设备，以中断接收模式打开 */
 result = rt_device_open(UART2_dev, RT_DEVICE_FLAG_INT_RX | RT_DEVICE_FLAG_INT_TX);
 if (result != RT_EOK)
 {
     rt_kprintf("Open %s failed!\n", UART2_DEVICE_NAME);
     return RT_ERROR;
 }
 /* 发送初始化消息 */
  rt_kprintf("%s", DEBUG_MESSAGE);




 return RT_EOK;
}


void ftUart_Send(uint8_t *nDat , int nLen)
{
    rt_device_write(UART2_dev, 0, nDat, nLen);
}

int ftUart_Read(uint8_t *nDat, int nLen)
{

    if((rt_device_read(UART2_dev, 0, nDat, nLen)) > 0){
        return nLen;
    }else{
        return 0;
    }
}


/* 导出初始化函数到自动初始化列表中 */
INIT_APP_EXPORT(UART2_app_init);


#endif
