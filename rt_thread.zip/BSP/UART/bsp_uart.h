/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-07     31879       the first version
 */
#ifndef APPLICATIONS_BSP_BSP_UART_H_
#define APPLICATIONS_BSP_BSP_UART_H_

#include <bsp_system.h>



#define UART1_ENABLE 1
#define UART2_ENABLE 1
#define UART5_ENABLE 1
#define UART6_ENABLE 1


extern uint16_t TOF_DATA;


int u1_printf(const char *format, ...);

void ftUart_Send(uint8_t *nDat , int nLen);
int ftUart_Read(uint8_t *nDat, int nLen);

#endif /* APPLICATIONS_BSP_BSP_UART_H_ */
