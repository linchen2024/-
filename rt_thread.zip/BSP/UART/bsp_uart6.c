/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-08     31879       the first version
 */
#include "bsp_uart.h"



#if UART6_ENABLE


#define SAMPLE_UART_NAME "uart6"

/* 信号量，用于接收数据通知 */
static struct rt_semaphore rx_sem;
static rt_device_t serial;

/* 接收回调函数 */
static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&rx_sem);  // 发送信号量
    return RT_EOK;
}
/* 处理串口接收到的数据 */
static void serial_thread_entry(void *parameter)
{
    char ch;

    uint8_t Temp[11] = {0};
    uint8_t counter = 0;
    float a[3],w[3],angle[3],T;

    while (1)
    {
        rt_sem_take(&rx_sem, RT_WAITING_FOREVER);  // 等待信号量
        while (rt_device_read(serial, -1, &ch, 1) == 1)
        {
            Temp[counter] = ch;   //接收数据
            if(counter == 0 && Temp[0] != 0x55) return;
            counter++;
            if(counter>=11) //接收到 11 个数据
            {
                counter=0; //重新赋值，准备下一帧数据的接收
                if(Temp[0]==0x55)       //检查帧头
                {
                   switch(Temp[1])
                   {
                      case 0x51: //标识这个包是加速度包
                         a[0] = ((short)(Temp[3]<<8 | Temp[2]))/32768.0*16;      //X轴加速度
                         a[1] = ((short)(Temp[5]<<8 | Temp[4]))/32768.0*16;      //Y轴加速度
                         a[2] = ((short)(Temp[7]<<8 | Temp[6]))/32768.0*16;      //Z轴加速度
                         T    = ((short)(Temp[9]<<8 | Temp[8]))/340.0+36.25;      //温度
                         break;
                      case 0x52: //标识这个包是角速度包
                         w[0] = ((short)(Temp[3]<<8| Temp[2]))/32768.0*2000;      //X轴角速度
                         w[1] = ((short)(Temp[5]<<8| Temp[4]))/32768.0*2000;      //Y轴角速度
                         w[2] = ((short)(Temp[7]<<8| Temp[6]))/32768.0*2000;      //Z轴角速度
                         T    = ((short)(Temp[9]<<8| Temp[8]))/340.0+36.25;      //温度
                         break;
                      case 0x53: //标识这个包是角度包
                         angle[0] = ((short)(Temp[3]<<8| Temp[2]))/32768.0*180;   //X轴滚转角（x 轴）
                         angle[1] = ((short)(Temp[5]<<8| Temp[4]))/32768.0*180;   //Y轴俯仰角（y 轴）
                         angle[2] = ((short)(Temp[7]<<8| Temp[6]))/32768.0*180;   //Z轴偏航角（z 轴）
                         T        = ((short)(Temp[9]<<8| Temp[8]))/340.0+36.25;   //温度

                         //printf("X轴角度：%.2f   Y轴角度：%.2f   Z轴角度：%.2f\r\n",angle[0],angle[1],angle[2]);
                         break;
                      default:  break;
                   }
                   memset(Temp, 0, strlen(Temp));
                   u1_printf("X角度：%.2f  Y角度：%.2f  Z角度：%.2f  X速度：%.2f  Y速度：%.2f  Z速度：%.2f\r\n",angle[0],angle[1],angle[2],w[0],w[1],w[2]);
                }
            }
        }
    }
}

static int uart_sample(void)
{
    /* 查找并打开串口设备 */
    serial = rt_device_find(SAMPLE_UART_NAME);
    rt_device_open(serial, RT_DEVICE_FLAG_INT_RX);

    /* 初始化信号量和接收回调 */
    rt_sem_init(&rx_sem, "rx_sem", 0, RT_IPC_FLAG_FIFO);
    rt_device_set_rx_indicate(serial, uart_input);

    /* 创建线程处理接收到的数据 */
    rt_thread_t thread = rt_thread_create("serial", serial_thread_entry, RT_NULL, 2048, 25, 10);
//    rt_thread_startup(thread);

    return 0;
}

INIT_APP_EXPORT(uart_sample);


#endif
