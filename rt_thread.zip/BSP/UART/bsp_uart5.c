/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-08     31879       the first version
 */
#include "bsp_uart.h"

#if UART5_ENABLE


uint16_t TOF_DATA = 0;


#define BUFFER_SIZE 256                // 环形缓冲区大小
#define UART5_DEVICE_NAME "uart5"       // 串口设备名称
#define DEBUG_MESSAGE "UART5 Application Initialized.\r\n"
#define UART5_TIMEOUT_TICKS 50          // 超时的系统tick数，具体值根据需求调整

/* 环形缓冲区存储池 */
static uint8_t rb_pool[BUFFER_SIZE];

/* 环形缓冲区对象 */
static struct rt_ringbuffer UART5_rb;

/* 读取数据的缓冲区 */
static uint8_t UART5_read_buffer[BUFFER_SIZE];

/* 用于同步的信号量 */
static struct rt_semaphore rx_sem;

/* UART5设备指针（用于重定向） */
static rt_device_t UART5_dev_redirect = RT_NULL;

struct rt_device *UART5_dev;

/* 记录上一次接收数据的tick */
static rt_tick_t last_rx_tick = 0;

int u5_printf(const char *format, ...)
{
 char buffer[512];  // 缓冲区大小，根据需求调整
 va_list args;
 va_start(args, format);

 // 使用 vsnprintf 格式化字符串到 buffer 中
 vsnprintf(buffer, sizeof(buffer), format, args);

 va_end(args);

 // 通过 rt_device_write 发送格式化后的字符串到串口1
 rt_device_write(UART5_dev_redirect, 0, buffer, strlen(buffer));

 return strlen(buffer);
}

/* UART5接收回调函数 */
static rt_err_t UART5_rx_ind(rt_device_t dev, rt_size_t size)
{
 rt_size_t read_size;
 rt_uint8_t temp_buffer[BUFFER_SIZE];

 /* 复位计时变量 */
 last_rx_tick = rt_tick_get();

 /* 从串口设备读取数据 */
 read_size = rt_device_read(UART5_dev, 0, temp_buffer, BUFFER_SIZE);

 if (read_size > 0)
 {
     /* 将读取的数据写入应用环形缓冲区 */
     size = rt_ringbuffer_put(&UART5_rb, temp_buffer, read_size);
     if (size < read_size)
     {
         /* 如果环形缓冲区空间不足，丢弃多余的数据 */
         u5_printf("Ringbuffer full! Data lost.\n");
     }
 }
 return RT_EOK;
}
uint16_t TOF_data_read(uint8_t *p_data)
{
    uint16_t TOF_Data = 0;
    TOF_Data = p_data[3]; //读回数据H
    TOF_Data <<= 8;
    TOF_Data |= p_data[4];//读回数据H

    return TOF_Data;
}
/* 数据处理线程入口函数 */
static void UART5_thread_entry(void *parameter)
{
 rt_size_t size;
 rt_tick_t current_tick;

 while (1)
 {
     /* 获取当前的tick值 */
     current_tick = rt_tick_get();

     /* 判断是否已经超时 */
     if (current_tick - last_rx_tick >= UART5_TIMEOUT_TICKS)
     {
         /* 如果超时了，认为数据已经接收完成，可以处理数据 */
         if (rt_ringbuffer_data_len(&UART5_rb) > 0)
         {
             size = rt_ringbuffer_get(&UART5_rb, UART5_read_buffer, sizeof(UART5_read_buffer) - 1);
             if (size > 0)
             {
                 /* 发送调试信息 */
//                 u5_printf("ringbuffer data: %s\r\n", UART5_read_buffer);
                 TOF_DATA = TOF_data_read(UART5_read_buffer);


                 /* 清空读取缓冲区 */
                 memset(UART5_read_buffer, 0, sizeof(UART5_read_buffer));
             }
         }
     }
     rt_thread_delay(50);
 }
}

/* 测试线程入口函数 */
static void test_thread_entry(void *parameter)
{
    while (1)
    {
        /* 打印测试信息 */
        u5_printf("Uart5 running\r\n");
        /* 延迟1秒（1000毫秒） */
        rt_thread_mdelay(1000);
    }
}

/* UART5应用初始化函数 */
int UART5_app_init(void)
{
 rt_err_t result;
 struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;
 rt_thread_t thread,test_thread;

 /* 初始化信号量 */
 rt_sem_init(&rx_sem, "rx_sem", 0, RT_IPC_FLAG_FIFO);

 /* 初始化环形缓冲区 */
 rt_ringbuffer_init(&UART5_rb, rb_pool, sizeof(rb_pool));

 /* 查找串口设备 */
 UART5_dev = rt_device_find(UART5_DEVICE_NAME);
 if (!UART5_dev)
 {
     rt_kprintf("Find %s failed!\n", UART5_DEVICE_NAME);
     return RT_ERROR;
 }

 /* 配置串口参数（可根据需要修改） */
 config.baud_rate = BAUD_RATE_115200; /* 波特率 */
 config.data_bits = DATA_BITS_8;      /* 数据位 */
 config.stop_bits = STOP_BITS_1;      /* 停止位 */
 config.parity    = PARITY_NONE;      /* 无奇偶校验 */
 config.bufsz     = BUFFER_SIZE;      /* 缓冲区大小 */

 /* 控制串口设备，设置配置参数 */
 result = rt_device_control(UART5_dev, RT_DEVICE_CTRL_CONFIG, &config);
 if (result != RT_EOK)
 {
     rt_kprintf("Configure %s failed!\n", UART5_DEVICE_NAME);
     return RT_ERROR;
 }

 /* 打开串口设备，以中断接收模式打开 */
 result = rt_device_open(UART5_dev, RT_DEVICE_FLAG_INT_RX | RT_DEVICE_FLAG_INT_TX);
 if (result != RT_EOK)
 {
     rt_kprintf("Open %s failed!\n", UART5_DEVICE_NAME);
     return RT_ERROR;
 }

 /* 设置接收回调函数 */
 rt_device_set_rx_indicate(UART5_dev, UART5_rx_ind);

 /* 重定向输出到UART5 */
 UART5_dev_redirect = UART5_dev;

 /* 发送初始化消息 */
 rt_kprintf("%s", DEBUG_MESSAGE);

 /* 创建数据处理线程 */
 thread = rt_thread_create("UART5_thread",
                           UART5_thread_entry,
                           (void *)UART5_dev,
                           4096,
                           RT_THREAD_PRIORITY_MAX / 2,
                           10);
 if (thread != RT_NULL)
 {
     rt_thread_startup(thread);
 }
 else
 {
     rt_kprintf("Create UART5_thread failed!\n");
     return RT_ERROR;
 }

 /* 创建测试线程 */
 test_thread = rt_thread_create("test_thread",
                                test_thread_entry,
                                RT_NULL,
                                2048,
                                RT_THREAD_PRIORITY_MAX / 3,
                                10);
 if (test_thread != RT_NULL)
 {
//     rt_thread_startup(test_thread);
 }
 else
 {
     rt_kprintf("Create test_thread failed!\n");
     return RT_ERROR;
 }

 return RT_EOK;
}

/* 导出初始化函数到自动初始化列表中 */
INIT_APP_EXPORT(UART5_app_init);


#endif
